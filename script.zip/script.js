document.addEventListener('DOMContentLoaded', () => {
    const yesButton = document.getElementById('yesButton');
    const noButton = document.getElementById('noButton');
    const messageContainer = document.getElementById('messageContainer');
    const sunflowersContainer = document.getElementById('sunflowersContainer');
    const container = document.querySelector('.container');
    const body = document.body;

    yesButton.addEventListener('click', () => {
        // Esconder os botões e o texto inicial
        container.classList.add('hidden');

        // Mostrar a mensagem e os girassóis
        messageContainer.style.display = 'block';
        messageContainer.innerHTML = '<p class="message">Assim como Van Gogh se encantava com as estrelas, eu me perco nos detalhes dos teus olhos, onde cada brilho é uma obra-prima que me faz sonhar acordada.</p>';
        
        body.classList.add('show-background');
        
        sunflowersContainer.style.display = 'block';
        for (let i = 0; i < 20; i++) {
            const sunflower = document.createElement('div');
            sunflower.className = 'sunflower';
            sunflower.style.left = `${Math.random() * 100}vw`;
            sunflower.style.top = `${Math.random() * 100}vh`;
            sunflowersContainer.appendChild(sunflower);
        }
    });

    noButton.addEventListener('mouseover', () => {
        const x = Math.random() * (window.innerWidth - noButton.offsetWidth);
        const y = Math.random() * (window.innerHeight - noButton.offsetHeight);
        noButton.style.position = 'absolute';
        noButton.style.left = `${x}px`;
        noButton.style.top = `${y}px`;
    });
});
